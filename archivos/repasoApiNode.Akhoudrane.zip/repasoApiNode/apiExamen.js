// Importa express
const express = require('express');
const app = express();  

//  para resta dos números
app.get('/restar/:num1/:num2', (req, res) => {
    const num1 = parseFloat(req.params.num1);
    const num2 = parseFloat(req.params.num2);

    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ msg: 'Ambos valores deben ser números.' });
    }

    const resultado = num1 - num2;
    res.json({ msg: `El resultado de la resta es: ${resultado}` });
});





app.get('/parImpar/:num1/', (req, res) => {
    const num1 = parseInt(req.params.num1);
    const resultado = num1 ;

    if (isNaN(num1)) {
        return res.status(400).json({ msg: 'debe ser números.' });
    }

    if(num1%2==0){
        res.json({ msg: `El  ${resultado} es par` });
    }else{
        res.json({ msg: `El  ${resultado} es impar` });
    }
});


app.get('/masCercano/:num1/', (req, res) => {
    const num1 = parseFloat(req.params.num1);
    const resultado =  Math.ceil(num1) ; //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/ceil

    if (isNaN(num1)) {
        return res.status(400).json({ msg: 'debe ser números.' });
    }

    
    res.json({ msg: `El numero más cercano es ${resultado} ` });
    
});


// Establece el puerto
const port = 3001;

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});
